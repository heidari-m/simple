# Example on how to make things with Class Based Views

Longer explanation (pt-br) in [here](https://medium.com/@leportella/class-based-views-no-django-d76b01ed644e)

TLDR:
  * views.py exemplifies how to make things using Class Based Views
  * old_views.py exemplifies same urls but with functions
